#####################################################################
###########################     R-Funktionen

##########################

# abrufen des Arbeitsverzeichnises
getwd()
## ein Arbeitsverzeichnis festlegen
setwd("C:/Users/gchri/OneDrive/SPS-Sudium/3. Semester/Elective Machine Learning")

#################################################################
##########################       Aufgabe


###############################################################################
#                                                                             #
#                                                                             #
#   Regressionsmodell zur automatisierten Bewertung von Eigentumswohnungen    #
#                                                                             #
#                                                                             #
###############################################################################
#   Projektteam:                      #
#   Anna Duregger, Christian Gruber   #
#                                     #
#######################################

###                                       ###
#   Tabelle einlesen                        #
#   Datentabelle wurde per GUI eingelesen   #
###                                       ###

###                                                                                                           ###
#   NA-Werte eliminieren und ein Subset vom Dataframe (df) mit ausschlie�lich numerischen Werten erstellen.     #
#   Alternativ zum Subset: Vorhandenen df k�rzen oder neuen angepassten df erzeugen,                            #
#   es wird subjektiv das vorgehen zur besten Nachvollziehbarkeit gew�hlt.                                      #
#   Mit Hilfe der numerischen Werte k�nnen wir eine correlation und chart.correlation durchf�hren               #
#   Wie Besprochen wird Spalte "Preis" nicht ber�cksichtigt                                                     #
#   Es folgen weitere detailierte Erkl�rungen als Annotationen in der nachfolgenden Programmierung.             #
###                                                                                                           ###


# Testlines bleiben unsortiert im Projekt, um evtl. Gedankeng�nge nachvollziehen zu k�nnen.
sum(is.na(daten,cols=c("preis","pqm")))
sum(is.na(daten$preis))
sum(!is.na(daten$moebel))
na.omit(daten$preis)
str(df2)
unique(c(df1$moebel))
library(stringr)
sum(str_count(df1,"mezzanine"))
unique(c(df$quelle))
library(plyr)
count(df2$moebel, vars = "1")

###                                                                                                           ###
#   Daten Tabelle erzeugen und dabei un�tige NA-, leere-, Sinnfreie-Werte eliminieren.                          #
#   Im Nachfolgenden wird der Dataframe "daten" so angepasst,                                                   #
#   sodass sp�ter ein schl�ssiges Multiples Regressionsmodell erstellt werden kann nachvollziehen zu k�nnen.    #
#   Hierf�r werden mehrere Variablen(objects) als Zwischenspeicher genutzt, um alle Einzelschritte              #
#   "Unsch�ner" Programmierstil wird hierbei vernachl�ssigt, da nicht Fokus des Kurses.                         #
###                                                                                                           ###

# Zeilen mit NA in Spalte "pqm" l�schen + Erzeugung df um Ursprungs Dataframe nicht zu ver�ndern.
datenohnePqmNA=na.omit(daten$pqm)
df <- daten[-c(datenohnePqmNA),]

# "preis" wird gel�scht, da wie besprochen, nicht ber�cksichtigt.
df1=df[,-which(names(daten)%in%c("preis"))]

# �berpr�fung des dataframes hinsichtlich der Spaltenformate.
str(df1)

###                               ###             
#    Spalte "Stockwerk" anpassen    #
###                               ###

unique(df1$stockwerk)
sum(str_count(df1,"mezzanine"))

# L�schen der Zeilen mit "mezzanine" da 147 vernachl�ssigbar sind 
# und keine Einordnung in ein Stockwerk vorgenommen werden kann.
df2=df1[- grep("mezzanine",df1$stockwerk),]

# Zeilen mit NA in Spalte "Stockwerk" aus df l�schen
sum(is.na(daten$stockwerk))

# PROBLEM: 79562 Datens�tze haben "NA" beim Stockwerk-> NA Zeilen l�schen oder behalten?
# Vorerst wird mit den "NA" Werten weitergearbeitet.
# "eg", "hochpatere", "souterrain" erhalten zur Vereinfachung Stockwerk "0"
df2$stockwerk=gsub("^hochparterre$","0",df2$stockwerk)
df2$stockwerk=gsub("^eg$","0",df2$stockwerk)
df2$stockwerk=gsub("^souterrain$","0",df2$stockwerk)
unique(df2$stockwerk)
length(which(df2$stockwerk == "21"))

#Umwandlung in numeric
df2$stockwerk<-as.numeric(df2$stockwerk) 
str(df2)

###                                                                                                   ###
# Zeilen mit strings in nummerische Werte �ndern. Es muss sp�ter gepr�ft werden,                        #
# ob in sinnvolle Werte umgewandelt wurde.                                                              #
# Au�erdem zu pr�fen, ob Umwandlung �berhaupt notwendig. Evtl. Verwendung als Kategorie sinnvoller.     #
###                                                                                                   ###

df2$moebel=gsub("^moebliert$","3",df2$moebel)
df2$moebel=gsub("^teilmoebliert$","1",df2$moebel)
df2$moebel=gsub("^moebliert teilmoebliert$","2",df2$moebel)

# Pr�fung -> Nur noch Zahlen (aber immer noch als char)
unique(df2$moebel)

# �berblick �ber die Anzahl der einzelnen Werte
length(which(df2$moebel == "1"))

#Umwandlung in numeric
df2$zimmer<-as.numeric(df2$zimmer) 
str(df2)

###                                                                                               ###
#   Umwandlung der restlichen Pr�diktoren als factors, um sie als categorical variables zu nutzen   #
#   Es werden vorsichtshakber alle Spalten in char umgewandelt, anschlie�end die NA Werte in        #
###                                                                                               ###

df2$quelle<-factor(df2$quelle)
levels(df2$quelle)

# Hier noch zus�tzlich order Funktion angewendet
df2$zustand <- factor(df2$zustand, levels = c("rohbau", "erstbezug", "erstbezug nach neubau","erstbezug nach sanierung","sehr gut","sehr gut/gut","gut","schlecht"), ordered = TRUE)
levels(df2$zustand)

df2$balkon <- as.numeric(as.character(df2$balkon))
df2$balkon[is.na(df2$balkon)] <- 0 
df2$balkon<-factor(df2$balkon)
levels(df2$balkon)

df2$terrasse <- as.numeric(as.character(df2$terrasse))
df2$terrasse[is.na(df2$terrasse)] <- 0 
df2$terrasse<-factor(df2$terrasse)

df2$garten <- as.numeric(as.character(df2$garten))
df2$garten[is.na(df2$garten)] <- 0 
df2$garten<-factor(df2$garten)

df2$wc <- as.numeric(as.character(df2$wc))
df2$wc[is.na(df2$wc)] <- 0 
df2$wc<-factor(df2$wc)

df2$loggia <- as.numeric(as.character(df2$loggia))
df2$loggia[is.na(df2$loggia)] <- 0 
df2$loggia<-factor(df2$loggia)

df2$keller <- as.numeric(as.character(df2$keller))
df2$keller[is.na(df2$keller)] <- 0 
df2$keller<-factor(df2$keller)

df2$abstellraum <- as.numeric(as.character(df2$abstellraum))
df2$abstellraum[is.na(df2$abstellraum)] <- 0 
df2$abstellraum<-factor(df2$abstellraum)

df2$lift <- as.numeric(as.character(df2$lift))
df2$lift[is.na(df2$lift)] <- 0 
df2$lift<-factor(df2$lift)

df2$anlagewohnung <- as.numeric(as.character(df2$anlagewohnung))
df2$anlagewohnung[is.na(df2$anlagewohnung)] <- 0 
df2$anlagewohnung<-factor(df2$anlagewohnung)

df2$dg <- as.numeric(as.character(df2$dg))
df2$dg[is.na(df2$dg)] <- 0 
df2$dg<-factor(df2$dg)

df2$penthouse <- as.numeric(as.character(df2$penthouse))
df2$penthouse[is.na(df2$penthouse)] <- 0 
df2$penthouse<-factor(df2$penthouse)

df2$luxus <- as.numeric(as.character(df2$luxus))
df2$luxus[is.na(df2$luxus)] <- 0 
df2$luxus<-factor(df2$luxus)

df2$fenster <- as.numeric(as.character(df2$fenster))
df2$fenster[is.na(df2$fenster)] <- 0 
df2$fenster<-factor(df2$fenster)

df2$belag <- as.numeric(as.character(df2$belag))
df2$belag[is.na(df2$belag)] <- 0 
df2$belag<-factor(df2$belag)

df2$bezug <- as.numeric(as.character(df2$bezug))
df2$bezug[is.na(df2$bezug)] <- 0 
df2$bezug<-factor(df2$bezug)

df2$parkett <- as.numeric(as.character(df2$parkett))
df2$parkett[is.na(df2$parkett)] <- 0 
df2$parkett<-factor(df2$parkett)

df2$garage <- as.numeric(as.character(df2$garage))
df2$garage[is.na(df2$garage)] <- 0 
df2$garage<-factor(df2$garage)

df2$maisonette <- as.numeric(as.character(df2$maisonette))
df2$maisonette[is.na(df2$maisonette)] <- 0 
df2$maisonette<-factor(df2$maisonette)

df2$kueche <- as.numeric(as.character(df2$kueche))
df2$kueche[is.na(df2$kueche)] <- 0 
df2$kueche<-factor(df2$kueche)

df2$klima <- as.numeric(as.character(df2$klima))
df2$klima[is.na(df2$klima)] <- 0 
df2$klima<-factor(df2$klima)

df2$moebel <- as.numeric(as.character(df2$moebel))
df2$moebel[is.na(df2$moebel)] <- 0 
df2$moebel<-factor(df2$moebel)

df2$jahr<-factor(df2$jahr)
str(df2)

# Erster Ansatz NAs in Baujahr, pqm und flaeche l�schen, da bei Berechnung hinderlich, 
# NAs in den Faktoren bereits durch Platzhalter ersetzt (z.B."0"),
# was bei den nummerischen Werten leider nicht ohne Weiteres m�glich ist. 
# Im zweiten Ansatz k�nnten evtl. sinnvolle Platzhalter gefunden werden,
# da durch die L�schung eine Verringerung der Datens�tze um ca.75% erfolgt.
dfohneNA=na.omit(df2)
dfohneNA

# L�schung unrealistischer Werte in der pqm-Spalte (L�schung von Werten > 9999??? pro m�)
# dfoNAuzgPQM = dataframe ohne NA und zu gro�en PQM
dfoNAuzgPQM=dfohneNA[!(dfohneNA$pqm>9999),]

# L�schung unrealistischer Werte (Werte < 0)
# dfoNAuzgPQMuN = dataframe ohne NA und zu gro�en PQM u Null
dfoNAuzgPQMuN=dfoNAuzgPQM[!(dfoNAuzgPQM$baujahr<0),]

###                     ###
#   Aufbau des Modells    #
###                     ###

input <- dfoNAuzgPQMuN
print(head(input))
str(dfoNAuzgPQMuN)
head(dfoNAuzgPQMuN$zustand)
# Relationshipmodell (Jahr und Quelle vorerst nicht ber�cksichtigt. Diese k�nnen aber nat. auch Einfluss haben)
model <- lm(dfoNAuzgPQMuN$pqm~dfoNAuzgPQMuN$baujahr+dfoNAuzgPQMuN$flaeche+dfoNAuzgPQMuN$stockwerk+
              dfoNAuzgPQMuN$zimmer+dfoNAuzgPQMuN$zustand+dfoNAuzgPQMuN$balkon+
              dfoNAuzgPQMuN$terrasse+dfoNAuzgPQMuN$garten+dfoNAuzgPQMuN$wc+dfoNAuzgPQMuN$loggia+
              dfoNAuzgPQMuN$keller+dfoNAuzgPQMuN$abstellraum+dfoNAuzgPQMuN$lift+dfoNAuzgPQMuN$anlagewohnung+
              dfoNAuzgPQMuN$dg+dfoNAuzgPQMuN$penthouse+dfoNAuzgPQMuN$luxus+dfoNAuzgPQMuN$fenster+
              dfoNAuzgPQMuN$belag+dfoNAuzgPQMuN$bezug+dfoNAuzgPQMuN$parkett+dfoNAuzgPQMuN$garage+dfoNAuzgPQMuN$maisonette+
              dfoNAuzgPQMuN$kueche+dfoNAuzgPQMuN$klima+dfoNAuzgPQMuN$moebel,dfoNAuzgPQMuN = input)
summary(model)
dummy.coef(model)
###########################################################################################
# Beispielrechnungsergebnis:                                                              #
# Eingesetzte Werte in Formel: BJ=2000, Fl�che=100, Stockwerk=1, Zimmer=3,                #
# Zustand="sehr gut", balkon=1, wc=1, restliche Spalten = 0                               #
# Rechnung: 4253,8871-1,0093*2000+4.8374*100+27,2693*1-6,7791*3....=3286,4555             #
# Auff�lligkeiten: Obwohl das Ergebnis plausibel wirkt ist es auff�llig, dass der Keller  #
# negativ in die Berechnung eingeht (-128.9383), obwohl ein Keller erh�hent auf den       #
# Preis einwirken sollte. Ist uns ein Fehler in der Aufstellung der Faktoren unterlaufen? #
###########################################################################################

# Zu Test- und Verst�ndniszwecken vereinfachtes Modell
model2 <- lm(dfoNAuzgPQMuN$pqm~dfoNAuzgPQMuN$flaeche+dfoNAuzgPQMuN$baujahr)
summary(model2)
dummy.coef(model2)
###########################################################################################
# Beispielrechnungsergebnis:                                                              #
# Eingesetzte Werte in Formel: BJ=2000, Fl�che=100                                        #
# Rechnung: -9050,4925???+5,8219*2000+10,0503*100=3598,3375???                                #
# Deutung: �hnliches Ergbnis wie das von "model" jeodch deutlicher Genaugikeitsverlust,   #
# da keine Faktoren ber�cksichtigt werden.                                                #
###########################################################################################

#Korrelationen
cor(dfoNAuzgPQMuN$pqm, dfoNAuzgPQMuN$flaeche, method="pearson")
#Ergebnis:[1] 0.2703063
cor(dfoNAuzgPQMuN$pqm, dfoNAuzgPQMuN$baujahr, method="pearson")
#Ergebnis:[1] 0.2190677

# Modell Formel aufstellen
print(model)
print(model2)
#########################################################################################
# Deutliche Unterschiede in den Entstehenden Formel erkennbar, wenn man das             #
# vereinfachte model2 und model(inkl. Faktoren) betrachtet.                             #
# --> Deutlicher Einfluss der Faktoren erkennbar.                                       #
#########################################################################################

###                                                                                   ###                                 
#                                         Plots                                         #
#                                                                                       #
#                                   Visualisierung in R                                 #
#                                                                                       #
###                                                                                   ###

#Einfacher Plot
plot(model)
plot(model2)

# Balkendiagram: Dient fuer Charakter- und Faktorvariablen
barplot(dfoNAuzgPQMuN$pqm)        # Fehlermeldung weil wir zuerst in eine Tabelle/Matrize Umwandeln muessen
barplot(table(dfoNAuzgPQMuN$pqm))

###                                         ###
#   Grafiken: Mit schoenen Beschriftungen:    #
###                                         ###

# Histogramm
hist(dfoNAuzgPQMuN$pqm,col="gray",ylab="Anzahl der Beobachtungen", 
     xlab="Verkehrswert [EUR]", breaks=20, 
     main="Histogramm: Verkehrswert von Immobilien")

# Boxplot

options(scipen=999) # scientific notation ausschalten

boxplot(pqm~zustand, data=dfoNAuzgPQMuN,col="gray",
        ylab="Verkehrswert [EUR]",xlab="Qualitaetsklassen",
        main="Boxplot:\n Verkehrswert von Immobilien")

#  Boxplot fuer bestimmte Werte aus dem Datensatz
bj2010 = subset(dfoNAuzgPQMuN,dfoNAuzgPQMuN$baujahr>=2010)
boxplot(bj2010$pqm)

####################################################################    
#                   Grafiken f�r Korrelationen                     #
####################################################################

# Achtung bei der plot Funktion wird zuerst x dann y eingegebn --> (x,y)
plot(dfoNAuzgPQMuN$flaeche, dfoNAuzgPQMuN$pqm,pch=19, col="gray")

# Trendlinien visualisieren
abline(lm(dfoNAuzgPQMuN$pqm ~ dfoNAuzgPQMuN$flaeche))

# Etwas buntere Grafiken
plot(dfoNAuzgPQMuN$flaeche, dfoNAuzgPQMuN$pqm, 
     main="Zusammenhang Verkehrswert und Fl�che",
     xlab="Fl�che", ylab="Verkehrswert", pch=19, col="gray")
abline(lm(dfoNAuzgPQMuN$pqm ~ dfoNAuzgPQMuN$flaeche), col="blue")

# ScatterplotMatrix -- Einfach:
pairs(~pqm+flaeche+baujahr+balkon+terrasse,data=dfoNAuzgPQMuN, 
      main="Einfache Scatterplot Matrix")

###########################################################################################
# Deutung nach Betrachtung aller Plots: Die Tabelle k�nnte noch weiter                    #
# verschlankt werden, da es noch einige "Ausreisser" gibt (z.B. Baujahre 1000-1200).      # 
# Andererseits verschleiert man hierdurch die Realergebnisse.                             #
###########################################################################################


###########################################################################################
# Nachfolgende Plots nur zum tieferen Verst�ndnis f�r RStudio Libraries, keine Auswertung.#
###########################################################################################

# scatterplotMatrix fortsetzung
install.packages("car") # Paket installieren
graphics.off() # Plot- bzw. Grafikausgabe zuruecksetzen
# aktiviere Paket
library(car) 

scatterplotMatrix(~pqm+flaeche+baujahr, data=daten, 
                  main="Trickreichere Scatterplot Matrix",smoother=F)

scatterplotMatrix(~pqm+flaeche+baujahr, data=daten, 
                  main="Trickreichste Scatterplot Matrix :P")
library(RColorBrewer)
my_colors = brewer.pal(nlevels(2), "Set4")
scatterplotMatrix(~pqm+flaeche+baujahr, 
                  data=daten, main="Scatterplot Matrix 10"
                  , smoother="", col=my_colors
                  , smoother.args=list(col="grey") , cex=0.5 , pch=c(15,16,17,18,19,20))


